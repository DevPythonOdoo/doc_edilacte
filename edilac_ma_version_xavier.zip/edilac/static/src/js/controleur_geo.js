/** @odoo-module **/

import { useService } from "@web/core/utils/hooks";
import { Component } from "@odoo/owl";

class FieldVisitController extends Component {
    constructor() {
        super(...arguments);
        this.rpc = this.env.services.rpc;
        this.notification = this.env.services.notification;
        this.loading = false; // État de chargement
    }

    async capturePositionForRecord(recordId) {
        try {
            this.loading = true; // Affiche le spinner pendant le traitement
            await this.env.services.rpc({
                model: "crm.lead",
                method: "capture_position",
                args: [recordId],
            });
            this.notification.add("Position capturée et enregistrée avec succès.", { type: "success" });
        } catch (error) {
            this.notification.add(`Erreur : ${error.message}`, { type: "danger" });
        } finally {
            this.loading = false; // Désactive le spinner après le traitement
        }
    }
}

// Associe le composant au template défini dans le XML
FieldVisitController.template = "edilac.field_visit_controller_template";

export default FieldVisitController;
