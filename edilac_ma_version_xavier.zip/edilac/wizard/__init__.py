from . import assignment
from . import partner
from . import freezer_paiement_wz
from . import field_visit_wz
