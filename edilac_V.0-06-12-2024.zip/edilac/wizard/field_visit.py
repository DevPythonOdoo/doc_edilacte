from odoo import fields, models, api


class FieldVisitWz(models.Model):
    _name = 'field.visit.wz'
    _description = 'Description'


