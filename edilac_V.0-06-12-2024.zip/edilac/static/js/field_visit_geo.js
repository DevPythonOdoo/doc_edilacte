/** @odoo-module **/
import { registry } from "@web/core/registry";
import { FormController } from "@web/views/form/form_controller";
import { loadJS } from "@web/core/assets";
mport { jsonrpc } from "@web/core/network/rpc_service";

const capturePositionButtonBehavior = {
    onButtonClicked(ev) {
        if (ev.data.attrs.name === 'capture_position') {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        // Appel RPC pour mettre à jour les coordonnées
                        this.rpc({
                            model: 'field.visit',
                            method: 'write',
                            args: [
                                [this.props.record.res_id],  // ID du record
                                {
                                    latitude: position.coords.latitude,
                                    longitude: position.coords.longitude,
                                },
                            ],
                        }).then(() => {
                            this.props.onRecordUpdated();
                        });
                    },
                    (error) => {
                        this.showNotification({
                            title: "Erreur de géolocalisation",
                            message: error.message,
                            type: "danger",
                        });
                    }
                );
            } else {
                this.showNotification({
                    title: "Erreur",
                    message: "La géolocalisation n'est pas prise en charge par ce navigateur.",
                    type: "danger",
                });
            }
        } else {
            // Appeler la méthode par défaut
            this._super(ev);
        }
    },
};

// Enregistrement dans le registry
registry.category("views").add("capture_position_button", {
    ...FormController,
    ...capturePositionButtonBehavior,
});
