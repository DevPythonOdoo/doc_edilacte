from odoo import api, models,exceptions


class CustomerWizard(models.AbstractModel):
    _name = 'report.edilac.report_customers_wizard_views'

    @api.model
    def _get_report_values(self, docids, data=None):
        customers = self.env['customers.wizard'].browse(docids)
        if 'res.partner(' in data['customers']:
            ids_str = data['customers'].split('(')[1].split(')')[0]  # Récupérer la partie entre ()
            customer_ids = [int(x.strip()) for x in ids_str.split(',')]  # Transformer en liste d'entiers
            
            # Parcourir la liste des IDs
            for customer_id in customer_ids:
                print(f"Client ID : {customer_id}")

        return {
            'doc_ids': docids,
            'doc_model': 'customers.wizard',
            'docs': self.env['res.partner'].browse(customer_ids),
            'data': data,

        }