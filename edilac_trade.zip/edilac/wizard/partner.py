# -*- coding: utf-8 -*-
import logging
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
from dateutil import relativedelta
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)



class InactiveCustomersWizard(models.TransientModel):
    _name = 'customers.wizard'
    _description = 'Inactive Customers Wizard'

    start_date = fields.Date(string="Date début",default=lambda *a: time.strftime('%Y-%m-01'), required=True)
    end_date = fields.Date(string="Date Fin", required=True,default=lambda *a: str(
        datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=-1))[:10])
    


    def generate_report(self):
        """Rechercher les clients inactifs et générer un rapport PDF."""
        self.ensure_one()
        orders = self.env['sale.order'].search([
            ('date_order', '>=', self.start_date),
            ('date_order', '<=', self.end_date),
            ('state', 'in', ['sale', 'done'])  # Filtrer les commandes confirmées
        ])
        active_customers = orders.mapped('partner_id.id')
        
        # Rechercher les clients qui n'ont pas passé de commande
        inactive_customers = self.env['res.partner'].search([
            ('id', 'not in', active_customers),
            ('customer_rank', '>', 0)  # Filtrer uniquement les clients
        ])
        #raise ValidationError("%s et %s"%(active_customers, inactive_customers))
        if not inactive_customers:
            raise UserError(_('Aucun client inactif trouvé sur la période.'))
        # Créer un rapport PDF
        report_data = {
            'start_date': self.start_date,
            'end_date': self.end_date,
            'customers': inactive_customers,
            
        }
        # {'ids': self.id, 'form': self.read(['date_from', 'date_to'])[0], 'model': 'hr.disa'}
        return self.env.ref('edilac.report_customers_wizards').report_action(self, data=report_data)
