# -*- coding: utf-8 -*-
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class ResUsers(models.Model):
    _inherit = 'res.users'

    as_a_salesperson = fields.Boolean('Comme un commercial')
    invoiced_target = fields.Monetary(string="Objectif de facturation")

    # invoiced_target = fields.Float(string="Objectif de facturation")
    target_ids = fields.One2many(
        string=_('Objectifs Commercial'),
        comodel_name='saleman.line',
        inverse_name='user_id',
    )
    customers_ids = fields.One2many(
        string=_('Clients suivi'),
        comodel_name='res.partner',
        inverse_name='user_id',
    )
    # date_start = fields.Date(string="Date début",related="target_ids.date_start", store=True)
    # date_end = fields.Date(string="Date fin",related="target_ids.date_end",store=True)
    target_amount = fields.Monetary(string="Montant dernier objectif",related="target_ids.target_amount",store=True)
    currency_id = fields.Many2one('res.currency', string="Devise",default=lambda self: self.env.company.currency_id)
    real_amount = fields.Monetary(string="Dernier CA",related="target_ids.real_amount",store=True)
    percentage = fields.Float(string="Pourcentage d'atteinte",compiled=True, store=True, compute='_compute_percentage')

    @api.depends('real_amount', 'target_amount')
    def _compute_percentage(self):
        for record in self:
            record.percentage = (record.real_amount / record.target_amount) * 100 if record.target_amount else 0.0

class SalemLine(models.Model):
    _name = 'saleman.line'
    _description = _('Objectif Commercial')
    _order = 'date_start desc'
    
    date_start = fields.Date(string="Date début",)
    date_end = fields.Date(string="Date fin",)
    target_amount = fields.Monetary(string="Montant objectif",)
    currency_id = fields.Many2one('res.currency', string="Devise",default=lambda self: self.env.company.currency_id)
    real_amount = fields.Monetary(string="Montant réel",store=True, compute='_compute_real_amount')
    percentage = fields.Float(string="Pourcentage d'atteinte", store=True, compute='_compute_percentage')
    user_id = fields.Many2one('res.users', string="Commercial")
    period  = fields.Float(string=_("Nombre de mois"),default=3)
    lines_ids = fields.One2many(
        string=_('Prévision Commerciale'),
        comodel_name='business.forecast',
        inverse_name='saleman_id')
    
    @api.depends('real_amount', 'target_amount')
    def _compute_percentage(self):
        for record in self:
            record.percentage = (record.real_amount / record.target_amount) * 100 if record.target_amount else 0.0
    
    @api.depends('lines_ids')
    def _compute_real_amount(self):
        for record in self:
            total_amount = 0.0
            for line in record.lines_ids:
                total_amount += line.amount
            
            record.real_amount = total_amount

    
    def forecast_confirm(self):
        data = []
        for record in self:
            if record.period == 0 or record.target_amount == 0 : 
                raise UserError("Veuillez saisir une période valide et un montant objectif.")
            result = self.env['sale.order'].calculate_market_share(record.user_id, record.target_amount, record.period)
            if result :
                if record.lines_ids:
                    # Supprimer les lignes existantes
                    record.lines_ids.unlink()
                # Afficher les résultats
                for client_id, market_share in result.items():
                    orders = self.env['sale.order'].search([('user_id', '=', record.user_id.id), ('state', 'in', ('sale','done')),
                    ('partner_id', '=', client_id),('date_order', '>=', record.date_start), ('date_order', '<=', record.date_end)])
                    self.env['business.forecast'].create({
                        'saleman_id': record.id,
                        'forecast_amount': round(market_share * 100, 2) ,
                        'target_amount': market_share*record.target_amount,
                        'partner_id': client_id,
                        'amount': sum(order.amount_total for order in orders),
                    })
        # self.env['business.forecast'].create(data)
        return True
                  
class BusinessForecast(models.Model):
    _name = 'business.forecast'
    _description = _('business.forecast')

    saleman_id = fields.Many2one(
        string=_('Commercial'),
        comodel_name='saleman.line', ondelete='cascade',
    )
    forecast_amount = fields.Float(string=_('Prévision %'))
    target_amount = fields.Monetary(string="Part de Marché")
    currency_id = fields.Many2one('res.currency', string="Devise",default=lambda self: self.env.company.currency_id)
    # compute_amount = fields.Float(string="Montant Calculé",compute='_compute_real_amount',store=True)
    amount = fields.Monetary(string="Montant réel")
    partner_id = fields.Many2one("res.partner", string=_('Client'),required=True)
    date_start = fields.Date(string="Date début",related='saleman_id.date_start',store=True)
    date_end = fields.Date(string="Date fin",related='saleman_id.date_end',store=True)
    
    # @api.depends('forecast_amount', 'target_amount')
    # def _compute_real_amount(self):
    #     for record in self:
    #         orders = self.env['sale.order'].search([('user_id', '=', record.saleman_id.user_id.id), ('state', 'in', ('sale','done')),
    #         ('partner_id', '=', record.partner_id.id),('date_order', '>=', record.saleman_id.date_start), ('date_order', '<=', record.saleman_id.date_end)])
    #         record.amount = sum(order.amount_total for order in orders)
    #         record.compute_amount =  1
    #         record.saleman_id.real_amount = record.saleman_id.real_amount  + record.amount 
        

class CrmTeam(models.Model):
    _inherit = 'crm.team'

    @api.model
    def write(self, vals):
        # Sauvegarder les utilisateurs actuels avant la mise à jour
        previous_members = self.member_ids
        # Appeler la méthode write pour effectuer la mise à jour
        res = super(CrmTeam, self).write(vals)
        # Récupérer les nouveaux membres après la mise à jour
        current_members = self.member_ids
        # Activer as_a_salesperson pour les utilisateurs ajoutés
        for user in current_members:
            if user not in previous_members:
                user.as_a_salesperson = True
        # Désactiver as_a_salesperson pour les utilisateurs supprimés
        for user in previous_members:
            if user not in current_members:
                user.as_a_salesperson = False

        return res

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    pricelist_id = fields.Many2one(comodel_name='product.pricelist', string='Liste de prix')
    region_id = fields.Many2one(comodel_name='region.region', string='Region')
    city_id = fields.Many2one(comodel_name='city.city',string='Ville')
    area_id = fields.Many2one(comodel_name='area.area',string='Zone')
    common_id = fields.Many2one(comodel_name='common.common',string='Commune')
    neighborhood_id = fields.Many2one(comodel_name='neighborhood.neighborhood',string='Quartier',required=True)
    industry_id = fields.Many2one(comodel_name='res.partner.industry',string="Secteur d'activité")
    customer_type = fields.Selection(string='Type de client', selection=[('tva', 'TVA OU TOTAL'), ('normal', 'Normal'),('normal_d', 'Normal déclaré')])
    customer_profil = fields.Selection(string='Profil client', selection=[('on', 'ON-US'), ('off', 'OFF-US')])
    company_type = fields.Selection(string='Type', selection=[('person', 'Particulier'), ('company', 'Societé')])
    is_won = fields.Boolean(string='Gagné', default=False)

    @api.onchange('neighborhood_id')
    def _onchange_neighborhood_id(self):
        if self.neighborhood_id:
            # Mise à jour des autres champs en fonction du quartier sélectionné
            self.common_id = self.neighborhood_id.common_id
            self.area_id = self.common_id.area_id
            self.city_id = self.area_id.city_id
            self.region_id = self.city_id.region_id
        else:
            # Réinitialisation des champs si aucun quartier n'est sélectionné
            self.common_id = False
            self.area_id = False
            self.city_id = False
            self.region_id = False

    def action_set_won(self):
        """ Won semantic: probability = 100 (active untouched) """
        self.action_unarchive()
        # group the leads by team_id, in order to write once by values couple (each write leads to frequency increment)
        leads_by_won_stage = {}
        for lead in self:
            values = {
                'property_product_pricelist': lead.pricelist_id.id,
                'user_id': lead.user_id.id,
                'region_id': lead.region_id.id,
                'city_id': lead.city_id.id,
                'area_id': lead.area_id.id,
                'common_id': lead.common_id.id,
                'neighborhood_id': lead.neighborhood_id.id,
                'customer_type': lead.customer_type,
                'customer_profil': lead.customer_profil,
                'industry_id': lead.industry_id.id,
                'name':lead.contact_name,
                'phone': lead.phone,
                'mobile': lead.mobile,
                'company_type': lead.company_type,
            }
            partner_id = self.env['res.partner'].create(values)
            won_stages = self._stage_find(domain=[('is_won', '=', True)], limit=None)
            # ABD : We could have a mixed pipeline, with "won" stages being separated by "standard"
            # stages. In the future, we may want to prevent any "standard" stage to have a higher
            # sequence than any "won" stage. But while this is not the case, searching
            # for the "won" stage while alterning the sequence order (see below) will correctly
            # handle such a case :
            #       stage sequence : [x] [x (won)] [y] [y (won)] [z] [z (won)]
            #       when in stage [y] and marked as "won", should go to the stage [y (won)],
            #       not in [x (won)] nor [z (won)]
            stage_id = next((stage for stage in won_stages if stage.sequence > lead.stage_id.sequence), None)
            if not stage_id:
                stage_id = next((stage for stage in reversed(won_stages) if stage.sequence <= lead.stage_id.sequence), won_stages)
            if stage_id in leads_by_won_stage:
                leads_by_won_stage[stage_id] += lead
            else:
                leads_by_won_stage[stage_id] = lead
        for won_stage_id, leads in leads_by_won_stage.items():
            leads.write({'stage_id': won_stage_id.id, 'probability': 100,'partner_id':partner_id.id,'is_won': True})
        return True
    

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    common_id = fields.Many2one(related='partner_id.common_id', string='Commune', store=True)
    neighborhood_id = fields.Many2one(related='partner_id.neighborhood_id', string='Quartier', store=True)
    area_id = fields.Many2one(related='partner_id.area_id', string='Zone', store=True)
    amount_paid = fields.Float(string="Montant Payé", compute='_compute_invoice_amounts', store=True)
    amount_due = fields.Float(string="Montant Dû", compute='_compute_invoice_amounts', store=True)

    @api.depends('invoice_ids.payment_state', 'invoice_ids.amount_total', 'invoice_ids.amount_residual')
    def _compute_invoice_amounts(self):
        for order in self:
            paid = 0.0
            due = 0.0
            # Parcourir toutes les factures liées à la commande
            for invoice in order.invoice_ids.filtered(lambda inv: inv.state == 'posted'):
                paid += invoice.amount_total - invoice.amount_residual
                due += invoice.amount_residual

            order.amount_paid = paid
            order.amount_due = due

    @api.depends('line_ids.amount_paid')
    def _compute_real_amount(self):
        for record in self:
            record.amount_paid = sum(order.amount_paid for order in record.line_ids if order.state in ('sale'))

    @api.model
    def create(self, vals):
        # Récupérer le partenaire et son type de client
        partner = self.env['res.partner'].browse(vals.get('partner_id'))
        prefix = 'S'  # Préfixe par défaut

        # Modifier le préfixe en fonction du type de client
        if partner.customer_type == 'tva':
            prefix = 'T'
        elif partner.customer_type == 'normal':
            prefix = 'N'
        elif partner.customer_type == 'normal_d':
            prefix = 'ND'

        # Générer le numéro de séquence en utilisant le préfixe personnalisé
        seq = self.env['ir.sequence'].next_by_code('sale.order') or '/'
        vals['name'] = prefix + seq[1:]  # Remplace le premier caractère par le préfixe désiré

        # Appeler la méthode create parente
        return super(SaleOrder, self).create(vals)
   
class saleOderLine(models.Model):
    _inherit = 'sale.order.line'

    date_order = fields.Datetime(string=_('Date Commande'), related='order_id.date_order',store=True,precompute=True)
    partner_type = fields.Selection(related='order_partner_id.customer_type', string=_('Type de client'),store=True,precompute=True)
    invoice_status = fields.Selection(related='order_id.invoice_status', string=_('Etat de facturation'),store=True,precompute=True)
    
class producpricelist(models.Model):
    _inherit = 'product.pricelist'

    state = fields.Selection(
        string=_('state'),
        selection=[
            ('draft', 'Nouveau'),
            ('send', 'Soumis'),
            ('done', 'Validé'),
        ], default='draft', readonly=True, tracking=True,
    )

    def action_submit(self):
        # for rec in self:
        #     if not rec.item_ids:
        #         raise exceptions.UserError('Veuillez ajouter des règles de tarification pour cette liste de prix.')
        self.write({"state": "send"})

    def action_validate(self):
        self.write({"state": "done"})

    def action_cancel(self):
        self.write({"state": "draft"})


class AccountMove(models.Model):
    _inherit = 'account.move'

    amount_paid = fields.Float(string="Montant Payé", compute='_compute_invoice_amounts', store=True)
    amount_due = fields.Float(string="Montant Dû", compute='_compute_invoice_amounts', store=True)

    @api.depends('payment_state', 'amount_total', 'amount_residual')
    def _compute_invoice_amounts(self):
        for order in self:
            paid = 0.0
            due = 0.0
            # Parcourir toutes les factures liées à la commande
            for invoice in order.filtered(lambda inv: inv.state == 'posted'):
                paid += invoice.amount_total - invoice.amount_residual
                due += invoice.amount_residual

            order.amount_paid = paid
            order.amount_due = due

    @api.depends('line_ids.amount_paid')
    def _compute_real_amount(self):
        for record in self:
            record.amount_paid = sum(order.amount_paid for order in record.line_ids if order.state in ('sale'))


