from odoo import models, fields, api,_
from odoo.exceptions import UserError

class StockMove(models.Model):
    _inherit = 'stock.move'

    gaps = fields.Float(string="ecart", default=0.00, copy=False)  
    quality_id = fields.Many2one(comodel_name='quality.quality',string='Qualité')  
    false_product_uom_qty = fields.Float('Quantités commandées', default=0.00, )
    manual_tranfert_move = fields.Boolean(string='Transfert manuel', default=False)
    
    
            
    @api.onchange('quantity', 'product_uom_qty')
    def _compute_ecart(self):
        for rec in self:
            if rec.quantity and rec.product_uom_qty:
                rec.gaps = rec.product_uom_qty - rec.quantity
                #rec.false_product_uom_qty = rec.quantity
            if rec.picking_code == 'internal' and rec.manual_tranfert_move:   
                quantity_requested = rec.product_uom_qty
                available_quantity = rec.product_id.with_context({'location': rec.location_id.id}).qty_available

                # Vérification si la quantité demandée est supérieure à la quantité disponible
                if quantity_requested > available_quantity:
                    raise UserError(_(
                        "La quantité à déplacer pour le produit %s est supérieure au stock actuel. "
                        "Vous avez seulement %s produits en stock dans l'emplacement %s."
                    ) % (rec.product_id.display_name, available_quantity, rec.location_id.display_name))
     
class Stock(models.Model):
    _inherit = 'stock.picking'

    total_ordered = fields.Float(string="Total commandé",default=0.00, compute='_cumul_total_sum', store=True, readonly=True)
    total_received = fields.Float(string="Total reçu", default=0.00, compute='_cumul_total_sum', store=True, readonly=True)
    total_ecart = fields.Float(string="Total ecart",default=0.00, compute='_cumul_total_sum', store=True, readonly=True)    
    manual_tranfert = fields.Boolean(string='Transfert manuel', default=False)
    type_code = fields.Char(string="Code Type Picking (première ligne)",compute="_cumul_total_sum", store=True)
    region_id = fields.Many2one('region.region', string="Région", related="partner_id.region_id")
    city_id = fields.Many2one('city.city', string="Ville", related="partner_id.city_id")
    area_id = fields.Many2one('area.area', string="Zone", related="partner_id.area_id")
    common_id = fields.Many2one('common.common', string="Commune", related="partner_id.common_id")
    neighborhood_id = fields.Many2one('neighborhood.neighborhood', string="Quartier", related="partner_id.neighborhood_id")
    delivery_ids = fields.One2many(comodel_name='delivery.delivery', inverse_name="picking_id", string='Livraison')
    deliv_person = fields.Char(string="livreur",compute="_check_livreur")
    
    def update(self):
        for rec in self:
            if rec.type_code == 'internal' and not rec.manual_tranfert:
                rec.manual_tranfert = True
                rec.move_ids_without_package.manual_tranfert_move = True
    
    @api.model
    def create(self, vals):
        record = super(Stock, self).create(vals)
        record.update()   
        return record
    
    @api.depends('move_ids_without_package')
    def _cumul_total_sum(self):
        for rec in self:
            rec.total_ordered = 0
            rec.total_received = 0
            rec.total_ecart = 0
            if rec.move_ids_without_package:
                rec.total_ordered = sum(rec.move_ids_without_package.mapped('product_uom_qty'))
                rec.total_received = sum(rec.move_ids_without_package.mapped('quantity'))
                rec.total_ecart = sum(rec.move_ids_without_package.mapped('gaps'))
                # Récupère le code du picking_type_id de la première ligne d'opération
                rec.type_code = rec.move_ids_without_package[0].picking_type_id.code
            else:
                rec.type_code = " "   


    @api.depends('delivery_ids')
    def _check_livreur(self):
        for rec in self:
            if rec.delivery_ids:
                # Récupère le nom du livreur de la première ligne d'opération
                rec.deliv_person = rec.delivery_ids[0].delivery_person_id.name
            else:
                rec.deliv_person = " "
           
           
    @api.onchange('move_ids_without_package')
    def check_stock_availability(self):
        """ Vérification de la disponibilité du stock pour chaque mouvement avant la confirmation du picking. """
        for picking in self:
            if picking.type_code == 'internal' and picking.manual_tranfert:
                for move in picking.move_ids_without_package:
                    quantity_requested = move.product_uom_qty
                    available_quantity = move.product_id.with_context({'location': move.location_id.id}).qty_available

                    # Vérification si la quantité demandée est supérieure à la quantité disponible
                    if quantity_requested > available_quantity:
                        raise UserError(_(
                            "La quantité à déplacer pour le produit %s est supérieure au stock actuel. "
                            "Vous avez seulement %s produits en stock dans l'emplacement %s."
                        ) % (move.product_id.display_name, available_quantity, move.location_id.display_name))
           
      

class Quality(models.Model):
    _name = 'quality.quality'
    _description = 'Qualités Produits'

    name = fields.Char(string='Libellé Qualité',required=True)
    
      
class Delivery(models.Model):
    _name = 'delivery.delivery'
    _description = 'Qualités Produits'

    ref = fields.Char(string='Référence')
    source = fields.Char(string='Source')
    contact_id = fields.Many2one('res.partner', string="Contact")
    area_id = fields.Many2one('area.area', string="Zone")
    delivery_person_id = fields.Many2one('res.partner', string="Livreur")
    picking_id = fields.Many2one('stock.picking')
    date = fields.Datetime(string='Date de livraison')
    
    
class StockBatch(models.Model):
    _inherit = 'stock.picking.batch'

    deliv_persons = fields.Char(string="Livreur",compute="check_deliv_person")  
    fleet_vehicle_id = fields.Many2one(comodel_name='fleet.vehicle', string='Vehicule', required=True,)
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('in_progress', 'En cours'),
        ('delivered', 'Livré'),
        ('done', 'Validé'),
        
        ('cancel', 'Annulé')], default='draft',
        store=True, compute='_compute_state',
        copy=False, tracking=True, readonly=True, index=True)
    
    def action_delivered(self):
        self.state = 'delivered'
    
    @api.depends('picking_ids')
    def check_deliv_person(self):
        for rec in self:
            if rec.picking_ids:
                # Récupère le nom du livreur de la première ligne d'opération
                rec.deliv_persons = rec.picking_ids[0].deliv_person
            else:
                rec.deliv_persons = " "    
  

class StockLot(models.Model):
    _inherit = 'stock.lot'

    product_qty = fields.Float('On Hand Quantity', compute='_product_qty', search='_search_product_qty',store=True)

    customer_affection_ids = fields.One2many(comodel_name='freezer.assignment', inverse_name='lot_id',
                                             string='Affectation Client', required=False)

    customer_affection_count = fields.Integer(
        string="'Nombre d'Affectation",
        required=False, compute="_compute_customer_affection_count", store=True)

    last_assignment = fields.Char(
        string='Dernière affectation chez',
        compute='_compute_last_assignment',
        store=True
    )

    @api.depends('customer_affection_ids')
    def _compute_last_assignment(self):
        for lot in self:
            # Si aucune affectation, laisser vide
            if not lot.customer_affection_ids:
                lot.last_assignment = ''
                continue
            # Trier les affectations par date décroissante
            last_assignment = lot.customer_affection_ids.sorted(lambda a: a.date, reverse=True)[:1]
            if last_assignment:
                # Construire une chaîne avec le nom du client et le numéro de série
                lot.last_assignment = f"{last_assignment.customer_id.name} ({last_assignment.lot_id.name})"
            else:
                lot.last_assignment = ''

    def button_open_customer_affection_count(self):
        return {

            'name': 'Affectation Client',
            'res_model': 'freezer.assignment',
            'view_mode': 'list,form',
            'context': {'edit': False, 'create': False},
            'domain': [('lot_id', '=', self.id)],
            'target': 'current',
            'type': 'ir.actions.act_window',
        }

    @api.depends('customer_affection_ids')
    def _compute_customer_affection_count(self):
        for rec in self:
            rec.customer_affection_count = len(rec.customer_affection_ids)


class StockLotType(models.Model):
    _inherit = 'stock.picking.type'

    is_free_transfer = fields.Boolean(string='Deploiement congelateur', default=False)








                            